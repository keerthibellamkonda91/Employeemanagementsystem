import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { MainDashboardComponent } from './components/main-dashboard/main-dashboard.component';
import { EmpDashboardComponent } from './components/emp-dashboard/emp-dashboard.component';
import { EmpFormComponent } from './components/emp-form/emp-form.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { SimpleModalComponent } from './components/modal/simple-modal/simple-modal.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatBadgeModule } from '@angular/material/badge';
import { MatPaginatorModule } from '@angular/material/paginator'; 
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import {MatDialogModule} from '@angular/material/dialog';
import { CardComponent } from './components/card/card.component';
import { FilterPipe } from './pipes/filter.pipe';
import { ConfirmDeleteComponent } from './components/deletecard/deletecard.component'


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MainDashboardComponent,
    EmpDashboardComponent,
    EmpFormComponent,
    NotFoundComponent,
    HeaderComponent,
    FooterComponent,
    CardComponent,
    SimpleModalComponent,
    AboutComponent,
    ContactComponent,
    FilterPipe,
    ConfirmDeleteComponent
  ],
  imports: [
    BrowserModule,
    MatBadgeModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatSortModule ,
    MatTableModule,
    MatPaginatorModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatDialogModule
  ],
  providers: [],
  entryComponents: [SimpleModalComponent, EmpFormComponent, ConfirmDeleteComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
