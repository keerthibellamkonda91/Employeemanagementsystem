import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { EmpInterface } from 'src/app/interfaces/app.model';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  @Output() deleteEvent = new EventEmitter<any>();
  @Output() editEvent = new EventEmitter<any>();
  @Input()
  config!: EmpInterface;
  constructor() { }

  ngOnInit(): void {
  }
/* Method to delete the card based on id */
  deleteCardHandler(id:number){
    this.deleteEvent.emit(id);
  }
/* Method to edit the card based on employeedata */
  editCardHandler(empData:EmpInterface){
    this.editEvent.emit(empData);
  }

}
