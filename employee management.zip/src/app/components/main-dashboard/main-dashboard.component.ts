import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { EmpInterface } from 'src/app/interfaces/app.model';
import { ApiService } from 'src/app/services/api.service';
import { SimpleModalComponent } from '../modal/simple-modal/simple-modal.component';
import { ConfirmDeleteComponent } from '../deletecard/deletecard.component';

@Component({
  selector: 'app-main-dashboard',
  templateUrl: './main-dashboard.component.html',
  styleUrls: ['./main-dashboard.component.scss'],
})
export class MainDashboardComponent implements OnInit, OnDestroy {
  private sub = new Subject();
  dashBoarddata: Array<EmpInterface> = [];
  deletemessage = '';
  deleteClass = '';
  searchTxt: any;
  constructor(private apiSrv: ApiService, private router: Router, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.getDashboardData();
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  getDashboardData() {
    this.apiSrv
      .getDashData()
      .pipe(takeUntil(this.sub))
      .subscribe((res) => {
        this.dashBoarddata = res as EmpInterface[];
      });
  }
/* Add Record */
  addRecordInfo() {
    this.router.navigate(['/empForm']);
  }
  confirmDeleteEvent(employeeId: number){
    let dialogRef = this.dialog.open(SimpleModalComponent);
    dialogRef.componentInstance.component = ConfirmDeleteComponent;
    dialogRef.componentInstance.apiSuccessEvent.pipe(takeUntil(this.sub)).subscribe((res) => {
      if (res) {
        this.deleteDashboardData(employeeId);
      }
    })
  }
  /* Delete Record */
  deleteDashboardData(employeeId: number) {
    this.apiSrv
      .deleteDashData(employeeId)
      .pipe(takeUntil(this.sub))
      .subscribe({
        next: (res) => {
          this.deletemessage = 'You have successfully deleted the Records';
          this.deleteClass = 'alert-success';
          this.getDashboardData();
        },
        error: (error) => {
          this.deletemessage = 'You are unable to delete the Record. Please try again..';
          this.deleteClass = 'alert-warning';
        },
      });
  }
 /* Edit Record */
  editDashboardData(empData: EmpInterface) {
    this.router.navigate(['/empForm'], { state: { empData } });
  }

}
