import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-deletecard',
  templateUrl: './deletecard.component.html',
  styleUrls: ['./deletecard.component.scss']
})
export class ConfirmDeleteComponent implements OnInit {
  @Output() apiSuccess = new EventEmitter<any>();
  constructor() { }

  ngOnInit(): void {
  }
/* Method to Delete the card data */
  deleteCarddata(){
    this.apiSuccess.emit(true);
  }

}
